<?php
    
return [
    /*
    |--------------------------------------------------------------------------
    | Full Project Message string
    |--------------------------------------------------------------------------
    |
    */
    'success' => 'Data added successfully',
    'update' => 'Data has been updated',
    'fail' => 'Something went wrong',
];