<footer class="footer footer-static footer-light">
  <p class="clearfix text-muted text-sm-center px-2"><span>{{Helper::webinfo()->copyright}}</span></p>
</footer>