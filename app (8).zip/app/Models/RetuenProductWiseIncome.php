<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RetuenProductWiseIncome extends Model
{
    use HasFactory;
    protected $table = 'return_product_wise_incomes';
    protected $guarded = [];
}