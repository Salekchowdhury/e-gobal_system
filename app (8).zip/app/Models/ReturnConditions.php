<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ReturnConditions extends Model
{
    protected $fillable = [
        'return_conditions'
    ];
}
