<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Products;
use App\Models\Purchase;
use App\Models\User;
use App\Models\Stockiest;
use App\Models\CurrentStockDetails;
use App\Models\CurrentStock;
use App\VSE;

class InvoiceController extends Controller
{
  

}